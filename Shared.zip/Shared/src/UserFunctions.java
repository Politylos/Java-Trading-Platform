public class UserFunctions {

    public User login(String username, String pasowrd){
        throw new UnsupportedOperationException();
    }
    public Boolean UpdatePassword(int userid, String new_password){
        return true;
    }
    public Boolean NewUser(String Username, String fname, String lname, String password, String email, int org_id){
        return true;
    }
    public void removeUser(int userid){

    }
}
