import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.io.Serial;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class Asset implements Asset_inter{
    @Serial
    private static final long serialVersionUID = -2852226688719086524L;
    String AssetName;
    int AssetId;
    String AssetDes;
    private double meanprice;
    private double minprice;
    private double maxprice;
    private HashMap<Date, Double> history = new HashMap<Date, Double>();
    public Asset(){ }
    public Asset(int Id, String Name,String AssetDes, HashMap<Date, Double> History) {
        AssetName = Name;
        AssetId = Id;
        this.AssetDes = AssetDes;
        this.history = History;
        calcAll();
    }
    public Asset(int Id, String Name, String AssetDes) throws SQLException, IOException, ClassNotFoundException, ParseException {
        AssetName = Name;
        AssetId = Id;
        this.AssetDes = AssetDes;
        DB dbhistory = new DB();
        String SQL_history = String.format("SELECT * FROM  tradehistory WHERE tradehistory.Trade_type = '1' AND tradehistory.Asset_id = %d", Id);
        dbhistory.query(SQL_history);
        SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
        while (dbhistory.next()){
            HashMap<String,String> row = dbhistory.Pop();
            history.put(format.parse(row.get("Post_date")), Double.parseDouble(row.get("Cost")));
        }
        calcAll();
    }

    @Override
    public String send() {
        return "Update ";
    }

    @Override
    public int getId() {
        return AssetId;
    }

    public void updateHistory(){

    }

    public Map getHistory(){
        throw new UnsupportedOperationException();
    }

    public void calcMin(){
        minprice = Double.POSITIVE_INFINITY;
        for (Map.Entry<Date,Double> pair : history.entrySet()){
            if (minprice > pair.getValue()){
                minprice=pair.getValue();
            }
        }
    }

    public void calMax(){
        maxprice = Double.NEGATIVE_INFINITY;
        for (Map.Entry<Date,Double> pair : history.entrySet()){
            if (maxprice < pair.getValue()){
                maxprice=pair.getValue();
            }
        }
    }
    public void calcAll(){
        double count =0;
        double total =0;
        maxprice = Double.NEGATIVE_INFINITY;
        minprice = Double.POSITIVE_INFINITY;
        for (Map.Entry<Date,Double> pair : history.entrySet()){
            count++;
            total+=pair.getValue();
            if (maxprice < pair.getValue()){
                maxprice=pair.getValue();
            }
            if (minprice > pair.getValue()){
                minprice=pair.getValue();
            }
        }
        meanprice = total/count;
    }
    public void calMean(){
        double count =0;
        double total =0;
        for (Map.Entry<Date,Double> pair : history.entrySet()){
            count++;
            total+=pair.getValue();
        }
        meanprice = total/count;
    }
    public double getMax(){
        return maxprice;
    }

    public double getMin(){
        return minprice;
    }

    public double getMean(){
        return meanprice;
    }

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeDouble(meanprice);
        out.writeDouble(minprice);
        out.writeDouble(maxprice);
        //out.writeObject(history);
        out.writeInt(AssetId);
        out.writeUTF(AssetName);
        out.writeUTF(AssetDes);
    }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        meanprice = in.readDouble();
        minprice = in.readDouble();
        maxprice = in.readDouble();
        //history = (Map<Date, Double>) in.readObject();
        AssetId = in.readInt();
        AssetName = in.readUTF();
        AssetDes = in.readUTF();
    }
}
