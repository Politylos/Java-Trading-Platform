import java.io.IOException;
import java.sql.SQLException;


public class Run {
    public static void main(String[] args) throws IOException, SQLException, ClassNotFoundException {


    }
}