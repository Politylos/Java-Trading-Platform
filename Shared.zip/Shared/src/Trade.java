import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

public class Trade implements Asset_inter {
    String AssetName;
    int AssetId;
    private int amount;
    private double price;
    private int type;
    private int org;
    private String AssetDes;
    private static final long serialVersionUID = -2856155523713386524L;

    public Trade(){}
    public Trade(int id,String AssetName, int Amount, double Price, int Type, int Org,String AssetDes){
        System.out.println(AssetName);
        this.AssetName = AssetName;
        this.AssetId = id;
        this.AssetDes = AssetDes;
        this.amount = Amount;
        this.price = Price;
        this.type = Type;
        this.org = Org;
    }
    public pack place_offer(int offer_org, int amount){
        int offer_type;
        if (type == 1){
            //sell to trade
            offer_type=1;
            return new pack(21,new String[] {String.valueOf(offer_org), String.valueOf(this.AssetId), String.valueOf(amount), String.valueOf(this.price)});
        } else{
            //buy trade
            offer_type = 2;
            return new pack(22,new String[] {String.valueOf(offer_org), String.valueOf(this.AssetId), String.valueOf(amount), String.valueOf(this.price)});
        }
    }
    public void place_offer(int offer_org){
        place_offer(offer_org, this.amount);

    }

    public void update(){

    }

    public int getAmount(){
        return amount;
    }

    public double getPrice(){
        return 1;
    }

    public double calcTotal(int amount){
        return 1;
    }
    @Override
    public String send() {
        return null;
    }

    @Override
    public int getId() {
        return 0;
    }

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeInt(AssetId);
        out.writeUTF(AssetName);
        out.writeInt(amount);
        out.writeDouble(price);
        out.writeInt(type);
        out.writeInt(org);
        out.writeUTF(AssetDes);
    }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        AssetId=in.readInt();
        AssetName =in.readUTF();
        amount=in.readInt();
        price=in.readDouble();
        type=in.readInt();
        org = in.readInt();
        AssetDes = in.readUTF();
    }

    public int getOrg() {
        return this.org;
    }
}
