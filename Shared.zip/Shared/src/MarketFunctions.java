public class MarketFunctions{

    public Boolean PlaceTrade(int OrgId, int assetId, double assetamount, String type){
        return true;
    }

    public Trade[] getTrades() {
            throw new UnsupportedOperationException();
    }

    public Trade getTrade(int tradeId){
        throw new UnsupportedOperationException();
    }

    public void sendTrade(int tradeId){

    }
    public Boolean RemoveTrade(int tradeId){
        return true;
    }

    public Asset[] getAssets(){
        throw new UnsupportedOperationException();
    }

    public Asset getAssets(int AssetId){
        throw new UnsupportedOperationException();
    }
}
