import java.io.IOException;

public class OrgFunctions {

    boolean newOrg(String name, double credits) throws IOException {
        return true;
    }

    boolean creditCheck(int orgId, double amount) throws IOException{
        return true;
    }

    Boolean updateCredits(int orgId, double amount) throws IOException{
        return true;
    }

    Boolean removeOrg(int orgId) throws IOException {
        return true;
    }

    organisation getOrg(int orgId){
        throw new UnsupportedOperationException();
    }

}
