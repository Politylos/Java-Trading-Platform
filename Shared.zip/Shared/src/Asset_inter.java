import java.io.Externalizable;

public interface Asset_inter extends Externalizable {

    public String send();
    public int getId();
}
