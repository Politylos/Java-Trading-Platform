import java.io.*;

public class pack implements Externalizable {
    private static final long serialVersionUID = -2856156319315086524L;
    private int command;
    private String[] args = null;
    public pack(int type, String[] args){
        command=type;
        this.args = args;
        System.out.println(type);
    }
    public pack(int type){
        command=type;
    }
    public pack(){}
    public int getType(){
        return command;
    }
    public String[] getArgs(){
        return args;
    }

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        String argsout=null;
        for (int i=0;i< args.length;i++){
            if (i==0){
                argsout = "";
            }
            argsout+=args[i];
            if (i != args.length-1){
                argsout+="|";
            }
        }
        System.out.println(argsout);
        out.writeUTF(argsout);
        System.out.println(command);
        out.writeInt(command);
    }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        String argsCompressed = in.readUTF();
        this.command = in.readInt();

        System.out.println(argsCompressed);
        this.args = argsCompressed.split("\\|");
        for (String q : this.args) {
            System.out.println(q);
        }
    }

}
