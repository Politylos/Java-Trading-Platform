import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;


public class GUI {
    //JFrame frame = Frame_setup();
    Market market; //init after user is signed in
    Server_Connector server;
    User user; //remove this and place inside the market place function
    //test arrays for testing before hooking up the GUI with the server/db
    //test user type
    private int userType = 0;
    //test user org as a string
    private final String userOrg = "Org 1";
    //test array for marketplace
    //TODO test array, i0=assetName, i1=assetQty, i2=price per unit,
    // i3=orderType(1==buy,2==sell), i4=posted by org, i5=dateposted, i6=tradeID
    private final String[][] testTradesArray = {{"Asset Type 1", "116", "2", "1", "Org 1", "12/12/2021","1"}
            ,{"Asset Type 1", "55", "3", "1", "Org 2", "12/12/2021","8"}
            ,{"Asset Type 1", "200", "1", "2", "Org 3", "12/12/2021","10"}
            ,{"Asset Type 2", "5", "115", "1", "Org 1", "12/12/2021","2"}
            ,{"Asset Type 3", "64", "4", "2", "Org 2", "12/12/2021","3"}
            ,{"Asset Type 4", "2", "1200", "1", "Org 1", "12/12/2021","4"}
            ,{"Asset Type 6", "172", "6", "1", "Org 4", "12/12/2021","5"}
            ,{"Asset Type 7", "23921", "14", "2", "Org 1", "12/12/2021","6"}
            ,{"Asset Type 8", "666", "6", "1", "Org 3", "12/12/2021","7"}
            ,{"Asset Type 10", "872", "5", "1", "Org 1", "12/12/2021","8"}};
    private final int noOfTrades = testTradesArray.length;
    //test price history array
    private final String [][] testPriceHistoryArray = {{"54","20", "23/02/21"},
            {"12","25", "29/05/21"},
            {"82","30", "15/03/21"},
            {"47","35", "01/04/21"},
            {"22","40", "22/05/21"}};
    //test org asset inventory
    private final String[][] testOrgAssetArray = {{"Asset Type 1", "100"}
            ,{"Asset Type 2", "5"}
            ,{"Asset Type 3", "64"}
            ,{"Asset Type 4", "2"}
            ,{"Asset Type 6", "172"}
            ,{"Asset Type 7", "23921"}
            ,{"Asset Type 8", "666"}
            ,{"Asset Type 10", "872"}};

    public GUI(Server_Connector server) throws NoSuchMethodException {
        this.server = server;
        Login Login_screen = new Login();
        //CreateAccountGUI createAccountGUI = new CreateAccountGUI();
        HomePageGUI homePageGUI = new HomePageGUI(user.getRole());
        //PlatformControlGUI platformControlGUI = new PlatformControlGUI();


        /*JFrame frame = new JFrame();

        JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createEmptyBorder(720, 420, 10, 30));
        panel.setLayout(new GridLayout(0, 1));

        frame.add(panel, BorderLayout.CENTER);

        frame.pack();
        frame.setVisible(true);*/
    }
//    private JFrame Frame_setup(){
//        JFrame frame = Frame_setup("Trading Platform");
//        return frame;
//    }
//    private JFrame Frame_setup(String title){
//        JFrame frame = new JFrame();
//        frame.setSize(720,423);
//        frame.setTitle(title);
//        frame.addWindowListener(new java.awt.event.WindowAdapter() {
//            public void windowClosing(java.awt.event.WindowEvent e) {
//                System.exit(0);
//            }
//        });
//        frame.pack();
//        frame.setVisible(true);
//        return frame;
//    }
    private JButton button(String text,Method perform, Object obj, Object pram,int w, int h){
        JButton btn = new JButton(text);
        btn.addActionListener(e -> {
            try {
                perform.invoke(obj);
            } catch (IllegalAccessException | InvocationTargetException illegalAccessException) {
                illegalAccessException.printStackTrace();
            }
        });
        btn.setMinimumSize(new Dimension(w,h));
        return btn;
    }
    private JTextField TextInput(int Columns){
        JTextField input = new JTextField(Columns);
        return input;
    }
    class TextInput {
        private String input = null;
        private JTextField textField;
        TextInput(){
            textField = new JTextField();
            textField.getDocument().addDocumentListener((new DocumentListener() {
                @Override
                public void insertUpdate(DocumentEvent e) {
                    input =textField.getText();
                    System.out.println(input);
                }

                @Override
                public void removeUpdate(DocumentEvent e) {
                    input =textField.getText();
                    System.out.println(input);
                }

                @Override
                public void changedUpdate(DocumentEvent e) {
                    input =textField.getText();
                    System.out.println(input);
                }
            }));
        }
        public JTextField addfeild(){
            return textField;
        }
        public String var(){
            return input;
        }
    }
    public class Login extends JFrame{

        private JTextField usernameTextField;
        private JPasswordField passwordField;
        private Method Submethod = Login.class.getMethod("submitLogin",null);
        private Method ClearFields = Login.class.getMethod("clearFields",null);
        private JButton loginButton = button("Login",Submethod,this,null,50,30);
        private JButton clearButton = button("Clear",ClearFields,this,null,50,30);


        public Login() throws NoSuchMethodException {
            initUI("Login - Trading Platform", 400, 300);
        }

        private void initUI(String title, int minWidth, int minHeight) {
            Container contentPane = this.getContentPane();
            contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
            contentPane.add(Box.createVerticalStrut(30));
            contentPane.add(makeEntryPanel());
            contentPane.add(Box.createVerticalStrut(30));
            contentPane.add(makeButtonPanel());
            contentPane.add(Box.createVerticalStrut(30));
            setTitle(title);
            setMinimumSize(new Dimension(minWidth, minHeight));
            pack();
            setVisible(true);
        }

        private JPanel makeEntryPanel() {
            JPanel entryPanel = new JPanel();
            GroupLayout layout = new GroupLayout(entryPanel);
            entryPanel.setLayout(layout);
            layout.setAutoCreateGaps(true);
            layout.setAutoCreateContainerGaps(true);

            JLabel usernameLabel = new JLabel("Username");
            JLabel passwordLabel = new JLabel("Password");
            usernameTextField = new JTextField(20);
            passwordField = new JPasswordField(20);

            GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();

            hGroup.addGroup(layout.createParallelGroup()
                    .addComponent(usernameLabel)
                    .addComponent(passwordLabel));
            hGroup.addGroup(layout.createParallelGroup()
                    .addComponent(usernameTextField)
                    .addComponent(passwordField));
            layout.setHorizontalGroup(hGroup);

            GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();

            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(usernameLabel).addComponent(usernameTextField));
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(passwordLabel).addComponent(passwordField));
            layout.setVerticalGroup(vGroup);
            return entryPanel;
        }

        private JPanel makeButtonPanel() {
            JPanel buttonPanel = new JPanel();
            buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
            buttonPanel.add(Box.createHorizontalStrut(50));
            buttonPanel.add(clearButton);
            buttonPanel.add(Box.createHorizontalStrut(50));
            buttonPanel.add(loginButton);
            return buttonPanel;
        }

        public void submitLogin() throws IOException, ClassNotFoundException, NoSuchMethodException {
            //String username = usernameTextField.getText();
            //String passwordStr = new String(passwordField.getPassword());
            //System.out.println("Username entered: " + username + ", Password entered: " + passwordStr);
            String[] login_info = {usernameTextField.getText(), new String(passwordField.getPassword())};
            server.establish();
            server.send(10,login_info);
            //Socket socket = server.getSocket();
            boolean login = false;
            //InputStream inputstream = socket.getInputStream();
            //ObjectInputStream serial = new ObjectInputStream(inputstream);
            try{
                System.out.println("found input");
                user = (User) server.fetch();
                user.print();
                login = true;

            } catch (Exception e){
                System.out.println("User not found");
            }
            if (login){
                server.establish();
                server.send(45);
                market = (Market) server.fetch();
                market.setUser(user);
                try{
                    System.out.println("found input");

                    login = true;
                    System.out.println("Got market");
                } catch (Exception e){
                    System.out.println("Market not found");
                    login = false;
                    user = null;
                }
            }
            if (login == true) {
                this.dispose();
                System.out.println(user.getRole());
                HomePageGUI homePageGUI = new HomePageGUI(user.getRole());
            }

            //ObjectInputStream serial = server.get();
            /*if (serial.readObject() != null) {


                System.out.println("Complete");
            } else{

            }*/
        }

        public void clearFields() {
            usernameTextField.setText("");
            passwordField.setText("");
        }

    }

    public class CreateAccountGUI extends JFrame {
        private Set<String> orgNames = new TreeSet<>();
        private final String[] userTypes = {"Generic User", "Administrator"};
        private JTextField setUsernameTextField;
        private JTextField setPasswordField;
        private JTextField setFNameField;
        private JTextField setLNameField;
        private JTextField setEmailField;
        private JComboBox<String> selectUserTypeCB;
        private JComboBox<String> selectOrganisationCB;
        private final Method confirmMethod = CreateAccountGUI.class.getMethod("confirmNewAccount");
        private final Method cancelMethod = CreateAccountGUI.class.getMethod("cancelNewAccount");
        private final JButton confirmButton = button("Confirm",confirmMethod,this,null,50,30);
        private final JButton cancelButton = button("Cancel",cancelMethod,this,null,50,30);

        public CreateAccountGUI() throws NoSuchMethodException {
            fillComboBox();
            initUI();
        }

        private void initUI() {
            Container contentPane = this.getContentPane();
            contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
            contentPane.add(Box.createVerticalStrut(30));
            contentPane.add(makeInputPanel());
            contentPane.add(Box.createVerticalStrut(30));
            contentPane.add(makeButtonPanel());
            contentPane.add(Box.createVerticalStrut(30));
            setTitle("New User - Trading Platform");
            setMinimumSize(new Dimension(400, 400));
            pack();
            setVisible(true);
        }

        /**
         * This is the Input Panel where an administrator
         * will input all of the new users information.
         * @return new user info input panel
         */
        private JPanel makeInputPanel() {
            JPanel inputPanel = new JPanel();
            GroupLayout layout = new GroupLayout(inputPanel);
            inputPanel.setLayout(layout);

            layout.setAutoCreateGaps(true);
            layout.setAutoCreateContainerGaps(true);

            JLabel setUsernameLabel = new JLabel("Set Username");
            JLabel setPasswordLabel = new JLabel("Set Password");
            JLabel setFNameLabel = new JLabel("Set First Name");
            JLabel setLNameLabel = new JLabel("Set Last Name");
            JLabel setEmailLabel = new JLabel("Set Email");
            JLabel setUserTypeLabel = new JLabel("User Type");
            JLabel setOrganisationLabel = new JLabel("Select Organisation");
            //text/pw fields
            setUsernameTextField = new JTextField(20);
            setPasswordField = new JTextField(20);
            setFNameField = new JTextField(20);
            setLNameField = new JTextField(20);
            setEmailField = new JTextField(20);
            //combo box
            selectUserTypeCB = new JComboBox<>(userTypes);
            String[] orgNameArray = orgNames.toArray(new String[orgNames.size()]);
            ComboBoxModel<String> model = new DefaultComboBoxModel<>(orgNameArray);
            selectOrganisationCB = new JComboBox<>();
            selectOrganisationCB.setModel(model);



            GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();

            hGroup.addGroup(layout.createParallelGroup()
                    .addComponent(setUsernameLabel)
                    .addComponent(setFNameLabel)
                    .addComponent(setLNameLabel)
                    .addComponent(setEmailLabel)
                    .addComponent(setPasswordLabel)
                    .addComponent(setUserTypeLabel)
                    .addComponent(setOrganisationLabel));
            hGroup.addGroup(layout.createParallelGroup()
                    .addComponent(setUsernameTextField)
                    .addComponent(setFNameField)
                    .addComponent(setLNameField)
                    .addComponent(setEmailField)
                    .addComponent(setPasswordField)
                    .addComponent(selectUserTypeCB)
                    .addComponent(selectOrganisationCB));
            layout.setHorizontalGroup(hGroup);

            GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();

            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(setUsernameLabel).addComponent(setUsernameTextField));
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(setFNameLabel).addComponent(setFNameField));
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(setLNameLabel).addComponent(setLNameField));
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(setEmailLabel).addComponent(setEmailField));
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(setPasswordLabel).addComponent(setPasswordField));
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(setUserTypeLabel).addComponent(selectUserTypeCB));
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(setOrganisationLabel).addComponent(selectOrganisationCB));
            layout.setVerticalGroup(vGroup);
            return inputPanel;
        }

        private JPanel makeButtonPanel() {
            JPanel buttonPanel = new JPanel();
            buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
            buttonPanel.add(Box.createHorizontalStrut(50));
            buttonPanel.add(cancelButton);
            buttonPanel.add(Box.createHorizontalStrut(50));
            buttonPanel.add(confirmButton);
            return buttonPanel;
        }


        private void fillComboBox() {
            try{
                //Not sure why but had to create a new instance of Server_Connector
                Server_Connector server_connector = new Server_Connector();
                //dummy args
                String[] arg1 = {"01", "02", "03", "04"};
                //System.out.println("Connecting to server to collect org name list");
                server_connector.establish();
                //System.out.println("server.establish complete");
                server_connector.send(43, arg1);
                ObjectInputStream ois = server_connector.get();
                orgNames = (Set<String>) ois.readObject();
                System.out.println(orgNames);
            } catch(Exception e){
                JOptionPane.showMessageDialog(null, e);
            }
        }

        /**
         * Sends new account information to server as String array {Username, Password, UserType, Organisation}
         */
        //TODO command 30 to add new user to DB if username is unique
        public void confirmNewAccount() throws IOException {
            //checks if any fields are empty
            if (setUsernameTextField.getText().equals("")
                    || setFNameField.getText().equals("")
                    || setLNameField.getText().equals("")
                    || setEmailField.getText().equals("")
                    || setPasswordField.getText().equals("")){
                JOptionPane.showMessageDialog(rootPane, "Please make sure all fields have a value.");
            } else {
                String[] new_account_info = {setUsernameTextField.getText(),
                        setFNameField.getText(),
                        setLNameField.getText(),
                        setEmailField.getText(),
                        setPasswordField.getText(),
                        String.valueOf(selectUserTypeCB.getSelectedItem()),
                        String.valueOf(selectOrganisationCB.getSelectedItem())};
                server.establish();
                server.send(30, new_account_info);
            }
        }

        public void cancelNewAccount() throws NoSuchMethodException {
            this.dispose();
            new HomePageGUI(user.getRole());
        }

    }

    /**
     * Home page; what every user will see after logging in
     * The button panel will change depending on whether the user is an admin or just generic user
     * user type specified by the param int userType
     */
    public class HomePageGUI extends JFrame {
        //Components for marketAccessPanel
        //NEED TO REPLACE THIS WITH ACTUAL ASSET TYPES FROM DB
        private String[] assetList = {"Asset Type 1", "Asset Type 2"};
        private JComboBox<String> selectAssetTypeCB;
        private final Method assetSearchMethod = HomePageGUI.class.getMethod("assetSearch");
        private final JButton assetSearchButton = button("Search",assetSearchMethod,this,null,50,30);
        private final Method viewMarketMethod = HomePageGUI.class.getMethod("openMarketPlace");
        private final JButton viewMarketButton = button("View Market", viewMarketMethod,this,null,50,30);
        private final Method newOrderMethod = HomePageGUI.class.getMethod("newOrder");
        private final JButton newOrderButton = button("New Order", newOrderMethod,this,null,50,30);
//        private final Method priceHistoryMethod = HomePageGUI.class.getMethod("priceHistory");
//        private final JButton priceHistoryButton = button("Price History", priceHistoryMethod, this, null, 50,30 );

        //Components for adminButtonPanel where userType == 1
        private final Method userControlMethod = HomePageGUI.class.getMethod("userControl");
        private final JButton userControlButton = button("User Control",userControlMethod,this,null,50,30);
        private final Method orgControlMethod = HomePageGUI.class.getMethod("orgControl");
        private final JButton orgControlButton = button("Org Control",orgControlMethod,this,null,50,30);
        private final Method platformControlMethod = HomePageGUI.class.getMethod("platformControl");
        private final JButton platformControlButton = button("Platform Control",platformControlMethod,this,null,50,30);
        private final Method newUserMethod = HomePageGUI.class.getMethod("newUser");
        private final JButton newUserButton = button("New User",newUserMethod,this,null,50,30);

        //Components for genericUserButtonPanel where userType == 2
        private final Method viewOrgInvMethod = HomePageGUI.class.getMethod("viewOrgAssets");
        private final JButton viewOrgInvButton = button("View Org Assets",viewOrgInvMethod,this,null,50,30);
        private final Method changePWMethod = HomePageGUI.class.getMethod("changePW");
        private final JButton changePWButton = button("Change PW",changePWMethod,this,null,50,30);

        public HomePageGUI(int role) throws NoSuchMethodException {
            userType = role;
            initUI(userType);
        }

        //userType arg will change the button panel depending on admin or generic user.
        private void initUI(int userType) {
            Container contentPane = this.getContentPane();
            contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
            contentPane.add(Box.createVerticalStrut(30));
            contentPane.add(makeInfoPanel());
            contentPane.add(Box.createVerticalStrut(30));
            contentPane.add(makeMarketAccessPanel());
            contentPane.add(Box.createVerticalStrut(30));
            contentPane.add(makeButtonPanel(userType));
            contentPane.add(Box.createVerticalStrut(30));
            setTitle("Home - Trading Platform");
            setMinimumSize(new Dimension(400, 400));
            pack();
            setVisible(true);
        }

        /**
         * The panel displaying logged in users Username, Organisation, and Org Credits
         * @return JPanel with logged in users info
         */
        private JPanel makeInfoPanel() {
            //need to get logged in users Username as string
            JLabel userNameLabel = new JLabel("Username");
            //need to get logged in users Org as string
            JLabel usersOrgLabel = new JLabel("Organisation");
            //need to get logged in users Orgs' credit qty as string
            JLabel orgCreditQtyLabel = new JLabel("Org Credits ###");

            JPanel infoPanel = new JPanel();
            infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.X_AXIS));
            infoPanel.add(Box.createHorizontalStrut(50));
            infoPanel.add(userNameLabel);
            infoPanel.add(Box.createHorizontalStrut(50));
            infoPanel.add(usersOrgLabel);
            infoPanel.add(Box.createHorizontalStrut(50));
            infoPanel.add(orgCreditQtyLabel);
            infoPanel.add(Box.createHorizontalStrut(50));
            return infoPanel;
        }

        private JPanel makeMarketAccessPanel() {
            JPanel marketAccessPanel = new JPanel();
            GroupLayout layout = new GroupLayout(marketAccessPanel);
            marketAccessPanel.setLayout(layout);

            layout.setAutoCreateGaps(true);
            layout.setAutoCreateContainerGaps(true);

            selectAssetTypeCB = new JComboBox<>(assetList);

            GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();

            hGroup.addGroup(layout.createParallelGroup().addComponent(selectAssetTypeCB)
                    .addComponent(viewMarketButton));
            hGroup.addGroup(layout.createParallelGroup().addComponent(assetSearchButton)
                    .addComponent(newOrderButton));
            layout.setHorizontalGroup(hGroup);

            GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(selectAssetTypeCB).addComponent(assetSearchButton));
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(viewMarketButton).addComponent(newOrderButton));
            layout.setVerticalGroup(vGroup);
            return marketAccessPanel;
        }

        public void assetSearch() throws NoSuchMethodException {
            new MarketPlaceViewGUI((String) selectAssetTypeCB.getSelectedItem());
        }

        public void openMarketPlace() throws NoSuchMethodException {
            //this one just opens marketPlaceViewGUI without any params so should show all current orders
            new MarketPlaceViewGUI();
        }

        public void newOrder(){
            try {
                new NewOrderGUI();
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            }
            //new NewOrderGUI();
        }

        /**
         * This panel will vary based on the Role of the user;
         * IF the user is an admin, they will have access to all admin function from here
         * Otherwise, generic users will be able to view their Orgs Asset Inventory, and change their own Password
         * @param userType - 1 == user is admin, 2 == user is generic user
         * @return button panel, either admin or generic user panel
         */
        private JPanel makeButtonPanel(int userType) {
            JPanel buttonPanel = new JPanel();
            if (userType == 1) {
                GroupLayout layout = new GroupLayout(buttonPanel);
                buttonPanel.setLayout(layout);
                layout.setAutoCreateGaps(true);
                layout.setAutoCreateContainerGaps(true);
                GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();
                hGroup.addGroup(layout.createParallelGroup()
                        .addComponent(userControlButton)
                        .addComponent(newUserButton));
                hGroup.addGroup(layout.createParallelGroup()
                        .addComponent(orgControlButton)
                        .addComponent(platformControlButton));
                layout.setHorizontalGroup(hGroup);
                GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();
                vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(userControlButton).addComponent(orgControlButton));
                vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(newUserButton).addComponent(platformControlButton));
                layout.setVerticalGroup(vGroup);

            } else if (userType == 2){
                buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
                buttonPanel.add(Box.createHorizontalStrut(50));
                buttonPanel.add(viewOrgInvButton);
                buttonPanel.add(Box.createHorizontalStrut(50));
                buttonPanel.add(changePWButton);
                buttonPanel.add(Box.createHorizontalStrut(50));
            } else{
                return null;
            }
            return buttonPanel;
        }

        public void viewOrgAssets(){
            new ViewOrgAssetsGUI();
        }

        public void priceHistory() {
            try {
                this.dispose();
                new PriceHistoryGUI();
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            }
        }

        public void changePW(){
            try {
                this.dispose();
                new ChangePasswordGUI();
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            }
        }

        public void userControl(){
            try {
                this.dispose();
                new UserControlGUI();
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            }
        }

        public void orgControl(){
            try {
                this.dispose();
                new OrganisationControlGUI();
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            }
        }

        public void newUser(){
            try {
                this.dispose();
                new CreateAccountGUI();
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            }
        }

        public void platformControl(){
            try {
                this.dispose();
                new PlatformControlOptionGUI();
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            }
        }

    }

    /**
     * Any logged in user should have access to this and be able to change their own password
     */
    public class ChangePasswordGUI extends JFrame {

        private JTextField inputOldPassword;
        private JTextField inputNewPassword;
        private JTextField inputConfirmNewPassword;
        private final Method confirmMethod = ChangePasswordGUI.class.getMethod("confirmNewPassword");
        private final Method cancelMethod = ChangePasswordGUI.class.getMethod("cancelNewPassword");
        private final JButton confirmButton = button("Confirm",confirmMethod,this,null,50,30);
        private final JButton cancelButton = button("Cancel",cancelMethod,this,null,50,30);


        public ChangePasswordGUI() throws NoSuchMethodException {
            initUI();
        }

        private void initUI() {
            Container contentPane = this.getContentPane();
            contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
            contentPane.add(Box.createVerticalStrut(30));
            contentPane.add(makeInputPanel());
            contentPane.add(Box.createVerticalStrut(30));
            contentPane.add(makeButtonPanel());
            contentPane.add(Box.createVerticalStrut(30));
            setTitle("Change Password - Trading Platform");
            setMinimumSize(new Dimension(300, 200));
            pack();
            setVisible(true);
        }

        private JPanel makeInputPanel() {
            JPanel inputPanel = new JPanel();
            GroupLayout layout = new GroupLayout(inputPanel);
            inputPanel.setLayout(layout);

            layout.setAutoCreateGaps(true);
            layout.setAutoCreateContainerGaps(true);

            JLabel oldPasswordLabel = new JLabel("Enter Current Password");
            JLabel newPasswordLabel = new JLabel("Enter New Password");
            JLabel confirmNewPasswordLabel = new JLabel("Confirm New Password");

            inputOldPassword = new JTextField(20);
            inputNewPassword = new JTextField(20);
            inputConfirmNewPassword = new JTextField(20);

            GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();

            hGroup.addGroup(layout.createParallelGroup()
                    .addComponent(oldPasswordLabel)
                    .addComponent(newPasswordLabel)
                    .addComponent(confirmNewPasswordLabel));
            hGroup.addGroup(layout.createParallelGroup()
                    .addComponent(inputOldPassword)
                    .addComponent(inputNewPassword)
                    .addComponent(inputConfirmNewPassword));
            layout.setHorizontalGroup(hGroup);

            GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();

            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(oldPasswordLabel).addComponent(inputOldPassword));
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(newPasswordLabel).addComponent(inputNewPassword));
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(confirmNewPasswordLabel).addComponent(inputConfirmNewPassword));
            layout.setVerticalGroup(vGroup);

            return inputPanel;
        }

        private JPanel makeButtonPanel() {
            //cancel button
            //confirm button (confirm method checks Old PW Matches, New PWs match, and then change to new PW in DB)
            JPanel buttonPanel = new JPanel();
            buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
            buttonPanel.add(Box.createHorizontalStrut(50));
            buttonPanel.add(cancelButton);
            buttonPanel.add(Box.createHorizontalStrut(50));
            buttonPanel.add(confirmButton);
            return buttonPanel;
        }

        public void confirmNewPassword(){
            if(inputNewPassword.getText().equals(inputConfirmNewPassword.getText())){
                //Check if old PW matches
                //if Old PW matches, change the users PW to inputNewPassword.getText();
                //else {JOptionPane.showMessageDialog(rootPane,"Current password is incorrect");
                //     clearTextFields();}
                System.out.println("Passwords match!");
            } else {
                JOptionPane.showMessageDialog(rootPane,"New passwords do not match. Please confirm your new password.");
                clearTextFields();
            }
        }

        public void clearTextFields(){
            inputOldPassword.setText("");
            inputNewPassword.setText("");
            inputConfirmNewPassword.setText("");
        }

        public void cancelNewPassword() throws NoSuchMethodException{
            this.dispose();
            new HomePageGUI(user.getRole());
            //cancel new password functionalities
        }
    }

    /**
     * Allows Generic User to view the amount of Assets owned by their own Organisation
     */
    public class ViewOrgAssetsGUI extends JFrame {
        //test 2d array to test org assets
        //3rows (this org owns 3 different kinds of assets)
        //2columns ([x][0] = Asset Name, [x][1] = Qty of Asset owned by org)

        private final int noOfAssets = testOrgAssetArray.length;

        public ViewOrgAssetsGUI() {
            initUI();
        }

        private void initUI() {
            Container contentPane = this.getContentPane();
            contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
            contentPane.add(Box.createVerticalStrut(30));
            contentPane.add(makeAssetInfoPanel());
            contentPane.add(Box.createVerticalStrut(30));
            setTitle("View + organisation.getOrgName + 's Assets - Trading Platform");
            setMinimumSize(new Dimension(400, 400));
            pack();
            setVisible(true);
        }

        private JScrollPane makeAssetInfoPanel() {
            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
            JScrollPane assetInfoPanel = new JScrollPane(panel);
            assetInfoPanel.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
            panel.add(Box.createVerticalStrut(15));
            for(int i = 0; i < noOfAssets; i++){
                panel.add(Box.createHorizontalStrut(10));
                panel.add(new JLabel(testOrgAssetArray[i][0] + " - Qty: " + testOrgAssetArray[i][1]));
                panel.add(Box.createVerticalStrut(30));
            }
            assetInfoPanel.setMinimumSize(new Dimension(200, 150));
            assetInfoPanel.setPreferredSize(new Dimension(300, 250));
            assetInfoPanel.setMaximumSize(new Dimension(300, 400));
            return assetInfoPanel;
        }
    }

    public class NewOrderGUI extends JFrame {
        private JComboBox<String> orderTypeOptionCB = new JComboBox<>();
        private JComboBox<String> assetTypeOptionCB = new JComboBox<>();
        private final Method confirmMethod = NewOrderGUI.class.getMethod("confirmNewOrder");
        private final Method cancelMethod = NewOrderGUI.class.getMethod("cancelNewOrder");
        private final JButton confirmButton = button("Confirm",confirmMethod,this,null,50,30);
        private final JButton cancelButton = button("Cancel",cancelMethod,this,null,50,30);

        public NewOrderGUI() throws NoSuchMethodException {
            initUI();
        }

        public void confirmNewOrder() throws NoSuchMethodException{
            //TODO
            //needs to check if org has enough credits/assets
            //if yes then take that qty of credits/assets from the org
            //this essentially "freezes" them, and they can be returned by canceling the order,
            //or another org fulfilling the order (which will be handled in the marketorderviewGUI)
        }

        public void cancelNewOrder() throws NoSuchMethodException{
            this.dispose();
            new HomePageGUI(user.getRole());
        }

        private void initUI() {
            Container contentPane = this.getContentPane();
            contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
            contentPane.add(Box.createVerticalStrut(30));
            contentPane.add(makeInputPanel());
            contentPane.add(Box.createVerticalStrut(30));
            contentPane.add(makeButtonPanel());
            contentPane.add(Box.createVerticalStrut(30));
            setTitle("New Order - Trading Platform");
            setMinimumSize(new Dimension(400, 400));
            pack();
            setVisible(true);
        }

        private JPanel makeInputPanel() {
            JPanel newOrderPanel = new JPanel();
            newOrderPanel.setLayout(new BoxLayout(newOrderPanel, BoxLayout.X_AXIS));
            GroupLayout layout = new GroupLayout(newOrderPanel);
            newOrderPanel.setLayout(layout);
            layout.setAutoCreateGaps(true);
            layout.setAutoCreateContainerGaps(true);

            final String[] orderOptions = new String[]{"PlaceHolder 1", "Placeholder 2"};
            final String[] assetOptions = new String[]{"PlaceHolder 1", "Placeholder 2"};

            orderTypeOptionCB = new JComboBox<>(orderOptions);

            JLabel orderTypeLabel = new JLabel("Order Type");
            JLabel assetTypeLabel = new JLabel("Asset Type");

            newOrderPanel.add(Box.createHorizontalStrut(50));
            newOrderPanel.add(orderTypeOptionCB);
            newOrderPanel.add(Box.createHorizontalStrut(50));

            assetTypeOptionCB = new JComboBox<>(assetOptions);

            newOrderPanel.add(Box.createHorizontalStrut(50));
            newOrderPanel.add(assetTypeOptionCB);
            newOrderPanel.add(Box.createHorizontalStrut(50));

            //Order Type ComboBox
            //Asset Type ComboBox
            JLabel QtyLabel = new JLabel("Quantity");
            JSpinner Qty = new JSpinner();
            Qty.setBounds(70, 70, 50, 40);
            newOrderPanel.add(Qty);

            JLabel pPerULabel = new JLabel("Price per Unit");
            JSpinner pPerU = new JSpinner();
            Qty.setBounds(70, 70, 50, 40);
            newOrderPanel.add(pPerU);
            //Qty JSpinner
            //$p/u JSpinner

            GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();
            hGroup.addGroup(layout.createParallelGroup()
                    .addComponent(orderTypeLabel)
                    .addComponent(assetTypeLabel)
                    .addComponent(QtyLabel)
                    .addComponent(pPerULabel));
            hGroup.addGroup(layout.createParallelGroup()
                    .addComponent(orderTypeOptionCB)
                    .addComponent(assetTypeOptionCB)
                    .addComponent(Qty)
                    .addComponent(pPerU));
            layout.setHorizontalGroup(hGroup);

            GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();

            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(orderTypeLabel).addComponent(orderTypeOptionCB));
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(assetTypeLabel).addComponent(assetTypeOptionCB));
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(QtyLabel).addComponent(Qty));
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(pPerULabel).addComponent(pPerU));
            layout.setVerticalGroup(vGroup);

            return newOrderPanel;
        }

        private JPanel makeButtonPanel() {
            JPanel buttonPanel = new JPanel();
            buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
            buttonPanel.add(Box.createHorizontalStrut(50));
            buttonPanel.add(cancelButton);
            buttonPanel.add(Box.createHorizontalStrut(50));
            buttonPanel.add(confirmButton);
            return buttonPanel;

        }

    }

    /**
     * This is a GUI class accessible by Admins
     * User is given a choice to create either a new Asset or new Organisation.
     * Once they have selected which to create, the main UI opens with different functions for each.
     */
    public class PlatformControlOptionGUI extends JFrame {

        //fields for the option UI.
        private JComboBox<String> selectOptionCB = new JComboBox<>();
        private final Method optionConfirmMethod = PlatformControlOptionGUI.class.getMethod("optionConfirm", null);
        private final JButton optionConfirmButton = button("Confirm", optionConfirmMethod, this, null, 50, 30);

        //cancel button
        private final Method cancelMethod = PlatformControlOptionGUI.class.getMethod("cancel", null);
        private final JButton cancelButton = button("Cancel", cancelMethod, this, null, 50, 30);

        public PlatformControlOptionGUI() throws NoSuchMethodException {
            initOptionUI();
        }

        /**
         * initialises the UI where the user will select whether to open the New Asset or New Organisation UI
         */
        private void initOptionUI(){
            Container contentPane = this.getContentPane();
            contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
            contentPane.add(Box.createVerticalStrut(30));
            contentPane.add(makeOptionInputPanel());
            contentPane.add(Box.createVerticalStrut(30));
            contentPane.add(makeOptionButtonPanel());
            contentPane.add(Box.createVerticalStrut(30));
            setTitle("Platform Control - Trading Platform");
            setMinimumSize(new Dimension(300, 200));
            pack();
            setVisible(true);
        }

        /**
         * Panel that contains JCombo box
         * where the user can choose to make a new asset or new organisation
         * @return JPanel with choice between new asset or new org
         */
        private JPanel makeOptionInputPanel() {
            JPanel optionInputPanel = new JPanel();
            optionInputPanel.setLayout(new BoxLayout(optionInputPanel, BoxLayout.X_AXIS));
            final String[] platformControlOptions = new String[]{"New Asset Type", "New Organisation"};

            selectOptionCB = new JComboBox<>(platformControlOptions);

            optionInputPanel.add(Box.createHorizontalStrut(50));
            optionInputPanel.add(selectOptionCB);
            optionInputPanel.add(Box.createHorizontalStrut(50));

            return optionInputPanel;
        }

        /**
         * Button panel for the "Middleman" GUI
         * @return panel containing confirm and cancel buttons
         */
        private JPanel makeOptionButtonPanel() {
            JPanel optionButtonPanel = new JPanel();
            optionButtonPanel.setLayout(new BoxLayout(optionButtonPanel, BoxLayout.X_AXIS));
            optionButtonPanel.add(Box.createHorizontalStrut(50));
            optionButtonPanel.add(cancelButton);
            optionButtonPanel.add(Box.createHorizontalStrut(50));
            optionButtonPanel.add(optionConfirmButton);
            optionButtonPanel.add(Box.createHorizontalStrut(50));
            return optionButtonPanel;
        }

        /**
         * method that gets executed when user clicks the cancel button
         * closes current window and opens the Homepage again.
         * @throws NoSuchMethodException
         */
        public void cancel() throws NoSuchMethodException {
            this.dispose();
            new HomePageGUI(user.getRole());
        }

        /**
         * method gets executed when user has selected whether to open the new org or new asset gui
         */
        public void optionConfirm(){
            //int to hold the selected option
            int platformControlOptionInt = selectOptionCB.getSelectedIndex();
            //open the main UI with selected option as param
            try {
                new PlatformControlMainGUI(platformControlOptionInt);
                this.dispose();
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            }
        }

    }

    public class PlatformControlMainGUI extends JFrame {

        //fields for the New Asset UI
        private JTextField newAssetNameField;
        private JTextArea newAssetDescTextArea;
        private final Method newAssetConfirmMethod = PlatformControlMainGUI.class.getMethod("confirmNewAsset", null);
        private final JButton newAssetConfirmButton = button("Confirm", newAssetConfirmMethod, this, null, 50, 30);

        //fields for the New Organisation UI
        private JTextField newOrgNameField;
        private final Method newOrgConfirmMethod = PlatformControlMainGUI.class.getMethod("confirmNewOrg", null);
        private final JButton newOrgConfirmButton = button("Confirm", newOrgConfirmMethod, this, null, 50, 30);

        //cancel button; returns user to home page.
        private final Method cancelMethod = PlatformControlMainGUI.class.getMethod("cancel", null);
        private final JButton cancelButton = button("Cancel", cancelMethod, this, null, 50, 30);

        public PlatformControlMainGUI(int selectedOption) throws NoSuchMethodException {
            initUI(selectedOption);
        }

        /**
         * init the main gui, either new asset or new org based on user selection
         * @param optionSelected - comboBox index where 0 opens new asset gui, 1 opens new org gui
         */
        private void initUI(int optionSelected) {
            if (optionSelected == 0) {
                Container contentPane = this.getContentPane();
                contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
                contentPane.add(Box.createVerticalStrut(30));
                contentPane.add(makeNewAssetPanel());
                contentPane.add(Box.createVerticalStrut(30));
                setTitle("New Asset - Trading Platform");
                setMinimumSize(new Dimension(300, 300));
                pack();
                setVisible(true);
                System.out.println("Should now open new asset UI");
            } else if (optionSelected == 1) {
                Container contentPane = this.getContentPane();
                contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
                contentPane.add(Box.createVerticalStrut(30));
                contentPane.add(makeNewOrgPanel());
                contentPane.add(Box.createVerticalStrut(30));
                setTitle("New Organisation - Trading Platform");
                setMinimumSize(new Dimension(300, 200));
                pack();
                setVisible(true);
                System.out.println("Should now open new org UI");
            } else {
                JOptionPane.showMessageDialog(null, "Error: Invalid Option Selected (somehow)");
            }
        }

        private JPanel makeNewAssetPanel() {
            JPanel newAssetPanel = new JPanel();
            GroupLayout layout = new GroupLayout(newAssetPanel);
            newAssetPanel.setLayout(layout);
            layout.setAutoCreateGaps(true);
            layout.setAutoCreateContainerGaps(true);

            JLabel newAssetNameLabel = new JLabel("Asset Name");
            JLabel newAssetDescLabel = new JLabel("Asset Description");
            newAssetNameField = new JTextField(20);
            newAssetDescTextArea = new JTextArea(1, 20);
            newAssetDescTextArea.setLineWrap(true);

            GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();
            //left hand side group
            hGroup.addGroup(layout.createParallelGroup()
                    .addComponent(newAssetNameLabel)
                    .addComponent(newAssetDescLabel)
                    .addComponent(cancelButton));
            //right hand side group
            hGroup.addGroup(layout.createParallelGroup()
                    .addComponent(newAssetNameField)
                    .addComponent(newAssetDescTextArea)
                    .addComponent(newAssetConfirmButton));
            layout.setHorizontalGroup(hGroup);

            GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();
            //1st row group
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(newAssetNameLabel).addComponent(newAssetNameField));
            //2nd row group
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(newAssetDescLabel).addComponent(newAssetDescTextArea));
            //3rd row group (buttons)
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(cancelButton).addComponent(newAssetConfirmButton));
            layout.setVerticalGroup(vGroup);
            return newAssetPanel;
        }

        private JPanel makeNewOrgPanel() {
            JPanel newOrgPanel = new JPanel();
            GroupLayout layout = new GroupLayout(newOrgPanel);
            newOrgPanel.setLayout(layout);

            layout.setAutoCreateGaps(true);

            layout.setAutoCreateContainerGaps(true);
            JLabel newOrgNameLabel = new JLabel("Organisation Name");
            newOrgNameField = new JTextField(20);

            GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();

            //left hand side group
            hGroup.addGroup(layout.createParallelGroup()
                    .addComponent(newOrgNameLabel)
                    .addComponent(cancelButton));
            //right hand side group
            hGroup.addGroup(layout.createParallelGroup()
                    .addComponent(newOrgNameField)
                    .addComponent(newOrgConfirmButton));
            layout.setHorizontalGroup(hGroup);

            GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();

            //1st row group
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(newOrgNameLabel).addComponent(newOrgNameField));
            //2nd row group (buttons)
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(cancelButton).addComponent(newOrgConfirmButton));
            layout.setVerticalGroup(vGroup);
            return newOrgPanel;
        }

        /**
         * Method which is executed when users pressed confirm on the new asset GUI.
         * Sends the entered asset name and description to the server to be entered into db
         * will not accept new asset if an asset already exists with the same name.
         * Description is optional.
         */
        public void confirmNewAsset(){
            String newAssetNameString;
            if (!newAssetNameField.getText().equals("")){
                newAssetNameString = newAssetNameField.getText();
                String newAssetDescriptionString = newAssetDescTextArea.getText();
                //handle invalid name (i.e. already exists in db) server side and pass back boolean to confirm.
                System.out.println("Should now add asset: " + newAssetNameString + " to db." +
                        "\nWith description: " + newAssetDescriptionString);
                //backend call to add new asset to db
            } else {
                JOptionPane.showMessageDialog(rootPane, "Please enter a name for this new asset.");
            }

        }

        /**
         * Method which is executed when user presses confirm on the new org GUI.
         * Sends the entered Org name to the server to create a new Org with that name with default 0 credits.
         * Also handles invalid org names (i.e. Org already exists with that name)
         */
        public void confirmNewOrg(){
            String newOrgNameString;
            if (!newOrgNameField.getText().equals("")){
                newOrgNameString = newOrgNameField.getText();
                //handle invalid name (i.e. already exists in db) server side and pass back boolean to confirm.
                System.out.println("Should now add org: " + newOrgNameString + " to db.");
                //backend call to add new asset to db
            } else {
                JOptionPane.showMessageDialog(rootPane, "Please enter a name for this new organisation.");
            }
        }

        public void cancel() throws NoSuchMethodException {
            this.dispose();
            new HomePageGUI(user.getRole());
        }


    }

    public class OrganisationControlGUI extends JFrame {
        //components for choosing which org to edit
        private JComboBox<String> orgToEditCB;
        ActionListener cbActionListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String orgSelected = (String) orgToEditCB.getSelectedItem();

                switch (Objects.requireNonNull(orgSelected)) {
                    case "Org 1" -> currentOrgCredits.setText("Org 1 Credits: ##");
                    case "Org 2" -> currentOrgCredits.setText("Org 2 Credits: ###");
                    case "Org 3" -> currentOrgCredits.setText("Org 3 Credits: ####");
                }
            }
        };
        //TODO replace these test arrays with Org + Asset names from DB
        private final String[] testOrgToEditArray = {"Org 1", "Org 2", "Org 3"};
        private final String[] testAssetArray = {"Asset 1", "Asset 2", "Asset 3"};

        //edit assets fields
        private JComboBox<String> changeAssetCB;
        private JSpinner changeAssetQty;
        private JCheckBox changeAssetCheck;

        //edit credits fields
        private JSpinner changeCreditQty;
        private JLabel currentOrgCredits;
        private JCheckBox changeCreditsCheck;

        //buttons
        private final Method cancelMethod = OrganisationControlGUI.class.getMethod("cancel");
        private final JButton cancelButton = button("Cancel",cancelMethod,this,null,50,30);
        private final Method confirmMethod = OrganisationControlGUI.class.getMethod("confirm");
        private final JButton confirmButton = button("Confirm",confirmMethod,this,null,50,30);

        public OrganisationControlGUI() throws NoSuchMethodException {
            initUI();
        }

        private void initUI() {
            Container contentPane = this.getContentPane();
            contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
            contentPane.add(Box.createVerticalStrut(30));
            contentPane.add(makeInputPanel());
            contentPane.add(Box.createVerticalStrut(30));
            contentPane.add(makeButtonPanel());
            contentPane.add(Box.createVerticalStrut(30));
            setTitle("Organisation Control - Trading Platform");
            setMinimumSize(new Dimension(400, 250));
            pack();
            setVisible(true);
        }

        private JPanel makeInputPanel() {
            JPanel inputPanel = new JPanel();
            GroupLayout layout = new GroupLayout(inputPanel);
            inputPanel.setLayout(layout);
            layout.setAutoCreateGaps(true);
            layout.setAutoCreateContainerGaps(true);
            //labels
            JLabel orgToEditLabel = new JLabel("Organisation to edit");
            JLabel editAssetLabel = new JLabel("Edit Asset");
            JLabel editCreditsLabel = new JLabel("Edit credits");
            //input components
            //org to edit cb with action listener
            orgToEditCB = new JComboBox<>(testOrgToEditArray);
            orgToEditCB.addActionListener(cbActionListener);
            //asset to change
            changeAssetCB = new JComboBox<>(testAssetArray);
            changeAssetQty = new JSpinner();
            changeAssetCheck = new JCheckBox("");
            changeAssetCheck.setSelected(false);
            //credit edit components
            changeCreditQty = new JSpinner();
            currentOrgCredits = new JLabel("Select an organisation to edit...");
            changeCreditsCheck = new JCheckBox("");
            changeAssetCheck.setSelected(false);

            GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();
            //far left side group (check boxes)
            hGroup.addGroup(layout.createParallelGroup()
                    .addComponent(changeAssetCheck)
                    .addComponent(changeCreditsCheck));
            //left side group (labels)
            hGroup.addGroup(layout.createParallelGroup()
                    .addComponent(currentOrgCredits)
                    .addComponent(orgToEditLabel)
                    .addComponent(editAssetLabel)
                    .addComponent(editCreditsLabel));
            //middle group (inputs)
            hGroup.addGroup(layout.createParallelGroup()
                    .addComponent(orgToEditCB)
                    .addComponent(changeAssetCB)
                    .addComponent(changeCreditQty));
            //right side group (asset qty spinner)
            hGroup.addGroup(layout.createParallelGroup()
                    .addComponent(changeAssetQty));
            layout.setHorizontalGroup(hGroup);

            GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();
            //org credits vgroup
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(currentOrgCredits));
            //select org to edit vgroup
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(orgToEditLabel)
                    .addComponent(orgToEditCB));
            //change asset vgroup
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(changeAssetCheck)
                    .addComponent(editAssetLabel)
                    .addComponent(changeAssetCB)
                    .addComponent(changeAssetQty));
            //change credit qty vgroup
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(changeCreditsCheck)
                    .addComponent(editCreditsLabel)
                    .addComponent(changeCreditQty));
            layout.setVerticalGroup(vGroup);

            return inputPanel;
        }

        private JPanel makeButtonPanel() {
            JPanel buttonPanel = new JPanel();
            buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
            buttonPanel.add(Box.createHorizontalStrut(50));
            buttonPanel.add(cancelButton);
            buttonPanel.add(Box.createHorizontalStrut(50));
            buttonPanel.add(confirmButton);
            return buttonPanel;
        }

        public void cancel(){
            try {
                this.dispose();
                new HomePageGUI(user.getRole());
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            }
        }

        public void confirm(){
            //store what org is selected
            String orgToEditString;
            orgToEditString = (String) orgToEditCB.getSelectedItem();
            //variables to store asset edit info
            String assetToChangeString;
            int assetChangeToQtyInt;
            //variables to store credit edit info
            int creditChangeToQtyInt;
            //check if user wants to change Asset qty
            if (changeAssetCheck.isSelected()){
                assetToChangeString = (String) changeAssetCB.getSelectedItem();
                assetChangeToQtyInt = (int) changeAssetQty.getValue();
                System.out.println("Changed " + orgToEditString
                        + "'s qty of " + assetToChangeString
                        + " to " + assetChangeToQtyInt);
            } else {
                System.out.println("Did not change " + orgToEditString + "'s assets.");
            }
            if (changeCreditsCheck.isSelected()){
                creditChangeToQtyInt = (int) changeCreditQty.getValue();
                System.out.println("Changed " + orgToEditString
                        + " credits amount to " + creditChangeToQtyInt);
            } else {
                System.out.println("Did not change " + orgToEditString + "'s credits.");
            }
        }
    }

    public class UserControlGUI extends JFrame {
        //input components
        private JTextField userToEditField;

        //change password components
        private JTextField changePWField;
        private JCheckBox changePWCheck;

        //change user type components
        private final String[] userTypeArray = {"Administrator", "Generic User"};
        private JComboBox<String> changeUserTypeCB;
        private JCheckBox changeUserTypeCheck;

        //change user org components
        //TODO get the org name list from DB. Current just a test array.
        private final String[] testUserOrgArray = {"Placeholder Org 1", "Placeholder Org 2"};
        private JComboBox<String> changeUserOrgCB;
        private JCheckBox changeUserOrgCheck;

        //buttons
        private final Method deleteAccountMethod = UserControlGUI.class.getMethod("deleteAccount");
        private final JButton deleteAccountButton = button("Delete",deleteAccountMethod,this,null,50,30);
        private final Method cancelMethod = UserControlGUI.class.getMethod("cancel");
        private final JButton cancelButton = button("Cancel",cancelMethod,this,null,50,30);
        private final Method confirmMethod = UserControlGUI.class.getMethod("confirm");
        private final JButton confirmButton = button("Confirm",confirmMethod,this,null,50,30);

        public UserControlGUI() throws NoSuchMethodException {
            initUI();
        }

        private void initUI() {
            Container contentPane = this.getContentPane();
            contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
            contentPane.add(Box.createVerticalStrut(30));
            contentPane.add(makeInputPanel());
            contentPane.add(Box.createVerticalStrut(30));
            contentPane.add(makeButtonPanel());
            contentPane.add(Box.createVerticalStrut(30));
            setTitle("User Control - Trading Platform");
            setMinimumSize(new Dimension(400, 400));
            pack();
            setVisible(true);
        }

        private JPanel makeInputPanel() {
            JPanel inputPanel = new JPanel();
            GroupLayout layout = new GroupLayout(inputPanel);
            inputPanel.setLayout(layout);
            layout.setAutoCreateGaps(true);
            layout.setAutoCreateContainerGaps(true);
            //Labels
            JLabel userToEditLabel = new JLabel("Username to edit");
            JLabel changePWLabel = new JLabel("Change Password");
            JLabel changeUserTypeLabel = new JLabel("Change User Role");
            JLabel changeUserOrgLabel = new JLabel("Change User Org");
            JLabel deleteAccountLabel = new JLabel("Delete Account");
            //input components
            userToEditField = new JTextField(20);
            changePWField = new JTextField(20);
            changeUserTypeCB = new JComboBox<>(userTypeArray);
            changeUserOrgCB = new JComboBox<>(testUserOrgArray);
            //check boxes
            changePWCheck = new JCheckBox("Edit?");
            changePWCheck.setSelected(false);
            changeUserTypeCheck = new JCheckBox("Edit?");
            changeUserTypeCheck.setSelected(false);
            changeUserOrgCheck = new JCheckBox("Edit?");
            changeUserOrgCheck.setSelected(false);

            GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();
            //left side group (labels)
            hGroup.addGroup(layout.createParallelGroup()
                    .addComponent(userToEditLabel)
                    .addComponent(changePWLabel)
                    .addComponent(changeUserTypeLabel)
                    .addComponent(changeUserOrgLabel)
                    .addComponent(deleteAccountLabel));
            //middle group (inputs)
            hGroup.addGroup(layout.createParallelGroup()
                    .addComponent(userToEditField)
                    .addComponent(changePWField)
                    .addComponent(changeUserTypeCB)
                    .addComponent(changeUserOrgCB)
                    .addComponent(deleteAccountButton));
            //right side group (check boxes)
            hGroup.addGroup(layout.createParallelGroup()
                    .addComponent(changePWCheck)
                    .addComponent(changeUserTypeCheck)
                    .addComponent(changeUserOrgCheck));
            layout.setHorizontalGroup(hGroup);

            GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();
            //enter username vgroup
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(userToEditLabel)
                    .addComponent(userToEditField));
            //change pw vgroup
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(changePWLabel)
                    .addComponent(changePWField)
                    .addComponent(changePWCheck));
            //change user type vgroup
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(changeUserTypeLabel)
                    .addComponent(changeUserTypeCB)
                    .addComponent(changeUserTypeCheck));
            //change user org vgroup
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(changeUserOrgLabel)
                    .addComponent(changeUserOrgCB)
                    .addComponent(changeUserOrgCheck));
            //delete account vgroup
            vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(deleteAccountLabel)
                    .addComponent(deleteAccountButton));
            layout.setVerticalGroup(vGroup);

            return inputPanel;
        }

        private JPanel makeButtonPanel() {
            JPanel buttonPanel = new JPanel();
            buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
            buttonPanel.add(Box.createHorizontalStrut(50));
            buttonPanel.add(cancelButton);
            buttonPanel.add(Box.createHorizontalStrut(50));
            buttonPanel.add(confirmButton);
            return buttonPanel;
        }

        public void deleteAccount(){
            //do the check if user exists, then delete account if it does
            if (!userToEditField.getText().equals("")){
                System.out.println("Deleted " + userToEditField.getText() + "'s Account.");
            } else {
                JOptionPane.showMessageDialog(rootPane,"Please ensure a valid username has been entered.");
            }

        }

        public void confirm(){
            //first, check if the username exists in the DB.
            //if not have dialog box popup and clear username textfield
            //if yes, check which check boxes have been selected.
            //then perform functions for each selected check box using the input users username.
            if (!userToEditField.getText().equals("")){
                //check if PW check is selected
                if (changePWCheck.isSelected()){
                    //check if PW field has anything entered
                    if (!changePWField.getText().equals("")){
                        System.out.println("Edited " + userToEditField.getText() + "'s Password.");
                    } else {
                        JOptionPane.showMessageDialog(rootPane,"Please ensure a valid password has been entered.");
                    }
                } else {
                    System.out.println("Didn't edit " + userToEditField.getText() + "'s Password.");
                }
                //check if change user type check has been selected
                if (changeUserTypeCheck.isSelected()){
                    System.out.println("Edited " + userToEditField.getText() + "'s User Type.");
                } else {
                    System.out.println("Didn't edit " + userToEditField.getText() + "'s User Type.");
                }
                //check if change user org check has been selected
                if (changeUserOrgCheck.isSelected()){
                    System.out.println("Edited " + userToEditField.getText() + "'s Organisation.");
                } else {
                    System.out.println("Didn't edit " + userToEditField.getText() + "'s Organisation.");
                }
            } else {
                JOptionPane.showMessageDialog(rootPane,"Please ensure a valid username has been entered.");
            }
        }

        public void cancel(){
            try {
                this.dispose();
                new HomePageGUI(user.getRole());
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            }
        }
        //needs option UI with textfield to type in user name to edit
        //needs to check if username exists before opening main UI
    }

    public class MarketPlaceViewGUI extends JFrame {
        //market place view, either have a view of all asset type listings
        //or if a specific asset has been selected view only listings of that asset





        /**
         * Constructor without params shows all active trade offers
         */
        public MarketPlaceViewGUI() throws NoSuchMethodException {
            initUI();
        }

        /**
         * Constructor takes param to display only active trade offers of a certain  asset type
         * @param assetName - The selected asset; only shows trades with this assetName.
         */
        public MarketPlaceViewGUI(String assetName) throws NoSuchMethodException {initUI(assetName);}

        /**
         * inits non param UI
         */
        private void initUI() {
            Container contentPane = this.getContentPane();
            contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
            contentPane.add(Box.createVerticalStrut(30));
            contentPane.add(makeMarketPlacePanel());
            contentPane.add(Box.createVerticalStrut(30));
            setTitle("Marketplace View - Trading Platform");
            setMinimumSize(new Dimension(400, 400));
            pack();
            setVisible(true);
        }

        /**
         * inits param UI
         * @param assetName - The selected asset; only shows trades with this assetName.
         */
        private void initUI(String assetName) {
            Container contentPane = this.getContentPane();
            contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
            contentPane.add(Box.createVerticalStrut(30));
            contentPane.add(makeMarketPlacePanel(assetName));
            contentPane.add(Box.createVerticalStrut(30));
            setTitle("Marketplace View: " + assetName + " - Trading Platform");
            setMinimumSize(new Dimension(400, 400));
            pack();
            setVisible(true);


        }

        /**
         * makes market place panel with all current trades
         * @return JScrollPane with all current trades
         */
        private JScrollPane makeMarketPlacePanel() {
            //panel layout stuff
            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
            JScrollPane marketPlacePanel = new JScrollPane(panel);
            marketPlacePanel.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
            panel.add(Box.createVerticalStrut(15));
            //fields to hold trade info
            String assetName;
            int assetQty;
            int pricePerUnit;
            int totalPrice;
            String orderType = null;
            String postedBy;
            String datePosted;
            int tradeID;
            JButton viewTradeBtn;

            //iteratively adds all trades from the testTradesArray
            for(int i = 0; i < noOfTrades; i++){
                assetName = testTradesArray[i][0];
                assetQty = Integer.parseInt(testTradesArray[i][1]);
                pricePerUnit = Integer.parseInt(testTradesArray[i][2]);
                totalPrice = assetQty * pricePerUnit;
                tradeID = Integer.parseInt(testTradesArray[i][6]);
                viewTradeBtn = new JButton("View Trade");
                viewTradeBtn.addActionListener(new ViewTradeActionListener(tradeID));
                if(testTradesArray[i][3].equals("1")){
                    orderType = "Buy Order";
                } else if (testTradesArray[i][3].equals("2")){
                    orderType = "Sell Order";
                }
                postedBy = testTradesArray[i][4];
                datePosted = testTradesArray[i][5];
                panel.add(Box.createHorizontalStrut(5));
                panel.add((new JLabel("+-----------------------------+")));
                panel.add(Box.createHorizontalStrut(5));
                panel.add(new JLabel("Asset: " + assetName));
                panel.add(Box.createHorizontalStrut(5));
                panel.add(new JLabel("Qty: " + assetQty));
                panel.add(Box.createHorizontalStrut(5));
                panel.add(new JLabel("Price p/unit: " + pricePerUnit));
                panel.add(Box.createHorizontalStrut(5));
                panel.add(new JLabel("Total price: " + totalPrice));
                panel.add(Box.createHorizontalStrut(5));
                panel.add(new JLabel(orderType));
                panel.add(Box.createHorizontalStrut(5));
                panel.add(new JLabel("Post by: " + postedBy));
                panel.add(Box.createHorizontalStrut(5));
                panel.add(new JLabel("Posted on: " + datePosted));
                panel.add(Box.createHorizontalStrut(5));
                panel.add(viewTradeBtn);
                panel.add(Box.createHorizontalStrut(5));
                panel.add((new JLabel("+-----------------------------+")));
                panel.add(Box.createVerticalStrut(30));
            }
            //more layout stuff
            marketPlacePanel.setMinimumSize(new Dimension(200, 150));
            marketPlacePanel.setPreferredSize(new Dimension(300, 250));
            marketPlacePanel.setMaximumSize(new Dimension(300, 400));
            return marketPlacePanel;
        }

        /**
         * makes the market place panel with only the queried asset type
         * @param assetNameQueried - shows only trades with this asset name
         * @return - JScrollPane with only queried assets
         */
        private JScrollPane makeMarketPlacePanel(String assetNameQueried) {
            //panel layout stuff
            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
            JScrollPane marketPlacePanel = new JScrollPane(panel);
            marketPlacePanel.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
            panel.add(Box.createVerticalStrut(15));
            //fields to hold trade info
            String assetName;
            int assetQty;
            int pricePerUnit;
            int totalPrice;
            String orderType = null;
            String postedBy;
            String datePosted;
            int tradeID;
            JButton viewTradeBtn;
            //iteratively adds all trades from the testTradesArray
            for(int i = 0; i < noOfTrades; i++){
                //checks for matching assetNames to assetNameQueried
                if(assetNameQueried.equals(testTradesArray[i][0])){
                    assetName = testTradesArray[i][0];
                    assetQty = Integer.parseInt(testTradesArray[i][1]);
                    pricePerUnit = Integer.parseInt(testTradesArray[i][2]);
                    totalPrice = assetQty * pricePerUnit;
                    tradeID = Integer.parseInt(testTradesArray[i][6]);
                    viewTradeBtn = new JButton("View Trade");
                    viewTradeBtn.addActionListener(new ViewTradeActionListener(tradeID));
                    if(testTradesArray[i][3].equals("1")){
                        orderType = "Buy Order";
                    } else if (testTradesArray[i][3].equals("2")){
                        orderType = "Sell Order";
                    }
                    postedBy = testTradesArray[i][4];
                    datePosted = testTradesArray[i][5];
                    panel.add(Box.createHorizontalStrut(5));
                    panel.add((new JLabel("+-----------------------------+")));
                    panel.add(Box.createHorizontalStrut(5));
                    panel.add(new JLabel("Asset: " + assetName));
                    panel.add(Box.createHorizontalStrut(5));
                    panel.add(new JLabel("Qty: " + assetQty));
                    panel.add(Box.createHorizontalStrut(5));
                    panel.add(new JLabel("Price p/unit: " + pricePerUnit));
                    panel.add(Box.createHorizontalStrut(5));
                    panel.add(new JLabel("Total price: " + totalPrice));
                    panel.add(Box.createHorizontalStrut(5));
                    panel.add(new JLabel(orderType));
                    panel.add(Box.createHorizontalStrut(5));
                    panel.add(new JLabel("Post by: " + postedBy));
                    panel.add(Box.createHorizontalStrut(5));
                    panel.add(new JLabel("Posted on: " + datePosted));
                    panel.add(Box.createHorizontalStrut(5));
                    panel.add(viewTradeBtn);
                    panel.add(Box.createHorizontalStrut(5));
                    panel.add((new JLabel("+-----------------------------+")));
                    panel.add(Box.createVerticalStrut(30));
                }
            }
            //more layout stuff
            marketPlacePanel.setMinimumSize(new Dimension(200, 150));
            marketPlacePanel.setPreferredSize(new Dimension(300, 250));
            marketPlacePanel.setMaximumSize(new Dimension(300, 400));
            return marketPlacePanel;
        }

        public void viewTrade(int tradeID){
            System.out.println("Should now open new window with details of tradeID " + tradeID);
            try {
                new MarketOrderViewGUI(tradeID);
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            }
        }

        /**
         * Action listener class that creates a button that takes the user to the correct view trade screen
         */
        public class ViewTradeActionListener implements ActionListener{
            private final int tradeID;

            public ViewTradeActionListener(int tradeID) {
                this.tradeID = tradeID;
            }

            @Override
            public void actionPerformed(ActionEvent e) {
                viewTrade(tradeID);
            }
        }
    }

    /**
     * Views a specific order, wth ability to interact with the order in various ways.
     */
    public class MarketOrderViewGUI extends JFrame {
        //opens from marketPlaceViewGUI
        //needs to take order ID as a param
        //needs to have different buttons based on if user is part of same Org and or if it's a buy/sell order
        //saves the info of the currently viewed order
        private String assetName;
        private int totalPrice;
        private int assetQty;
        private int pricePerUnit;
        private String orderType = null;
        private String postedBy;
        private String datePosted;
        //final label texts
        private final String SELL_LABEL = "Sell Qty: ";
        private final String BUY_LABEL = "Buy Qty: ";
        //this saves the i value where the correct trade was found in the trade array
        //so the correct value returned to when performing functions on the trade
        private int iSaved;
        private JSpinner qtySelectSpinner;
        //btns
        private final Method placeOrderMethod = MarketOrderViewGUI.class.getMethod("placeOrder");
        private final JButton placeOrderBtn = button("Place Order",placeOrderMethod,this,null,50,30);
        private final Method cancelOrderMethod = MarketOrderViewGUI.class.getMethod("cancelOrder");
        private final JButton cancelOrderBtn = button("Cancel Order",cancelOrderMethod,this,null,50,30);
        private final Method priceHistoryMethod = MarketOrderViewGUI.class.getMethod("priceHistory");
        private final JButton priceHistoryBtn = button("Price History",priceHistoryMethod,this,null,50,30);

        public MarketOrderViewGUI(int tradeID) throws NoSuchMethodException {
            initUI(tradeID);
        }

        private void initUI(int tradeID) {
            Container contentPane = this.getContentPane();
            contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
            contentPane.add(Box.createVerticalStrut(30));
            contentPane.add(makeOrderInfoPanel(tradeID));
            contentPane.add(Box.createVerticalStrut(30));
            contentPane.add(makeButtonPanel());
            contentPane.add(Box.createVerticalStrut(30));
            setTitle("View + organisation.getOrgName + 's Assets - Trading Platform");
            setMinimumSize(new Dimension(400, 400));
            pack();
            setVisible(true);
        }

        private JPanel makeOrderInfoPanel(int tradeID) {
            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

            int checkTradeID;
            //iteratively adds all trades from the testTradesArray
            for(int i = 0; i < noOfTrades; i++){
                checkTradeID = Integer.parseInt(testTradesArray[i][6]);
                //checks for matching assetNames to assetNameQueried
                if(tradeID == checkTradeID){
                    assetName = testTradesArray[i][0];
                    assetQty = Integer.parseInt(testTradesArray[i][1]);
                    pricePerUnit = Integer.parseInt(testTradesArray[i][2]);
                    totalPrice = assetQty * pricePerUnit;
                    //tradeID = Integer.parseInt(testTradesArray[i][6]);
                    if(testTradesArray[i][3].equals("1")){
                        orderType = "Buy Order";
                    } else if (testTradesArray[i][3].equals("2")){
                        orderType = "Sell Order";
                    }
                    postedBy = testTradesArray[i][4];
                    datePosted = testTradesArray[i][5];
                    panel.add(Box.createHorizontalStrut(5));
                    panel.add((new JLabel("+-----------------------------+")));
                    panel.add(Box.createHorizontalStrut(5));
                    panel.add(new JLabel("Asset: " + assetName));
                    panel.add(Box.createHorizontalStrut(5));
                    panel.add(new JLabel("Qty: " + assetQty));
                    panel.add(Box.createHorizontalStrut(5));
                    panel.add(new JLabel("Price p/unit: " + pricePerUnit));
                    panel.add(Box.createHorizontalStrut(5));
                    panel.add(new JLabel("Total price: " + totalPrice));
                    panel.add(Box.createHorizontalStrut(5));
                    panel.add(new JLabel(orderType));
                    panel.add(Box.createHorizontalStrut(5));
                    panel.add(new JLabel("Post by: " + postedBy));
                    panel.add(Box.createHorizontalStrut(5));
                    panel.add(new JLabel("Posted on: " + datePosted));
                    panel.add(Box.createHorizontalStrut(5));
                    panel.add((new JLabel("+-----------------------------+")));
                    panel.add(Box.createVerticalStrut(30));
                    iSaved = i;
                    break;
                }
            }
            panel.setMinimumSize(new Dimension(200, 150));
            panel.setPreferredSize(new Dimension(300, 250));
            panel.setMaximumSize(new Dimension(300, 400));
            return panel;
        }

        private JPanel makeButtonPanel() {
            String labelText = "Something's wrong";
            qtySelectSpinner = new JSpinner();
            JPanel buttonPanel = new JPanel();
            buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
            buttonPanel.add(Box.createHorizontalStrut(50));
            //first we need to check if the trade comes from the users organisation
            if (userOrg.equals(testTradesArray[iSaved][4])){
                buttonPanel.add(cancelOrderBtn);
                buttonPanel.add(Box.createHorizontalStrut(50));
                buttonPanel.add(priceHistoryBtn);
                buttonPanel.add(Box.createHorizontalStrut(50));
            } else if (!userOrg.equals(testTradesArray[iSaved][4])) {
                if (testTradesArray[iSaved][3].equals("1")){
                    labelText = SELL_LABEL;
                } else if (testTradesArray[iSaved][3].equals("2")){
                    labelText = BUY_LABEL;
                }
                buttonPanel.add(new JLabel(labelText));
                buttonPanel.add(Box.createHorizontalStrut(50));
                buttonPanel.add(qtySelectSpinner);
                buttonPanel.add(Box.createHorizontalStrut(50));
                buttonPanel.add(placeOrderBtn);
                buttonPanel.add(Box.createHorizontalStrut(50));
            }
            return buttonPanel;
        }

        public void placeOrder(){
            //do some error checking to check if there's enough credits/assets
            //then add qty of to new orgs account
            //probably also should add to the price history table here i guess
        }

        public void cancelOrder(){
            //return the frozen credits/assets to the org the order originated from
            //check buy/sell order
            //if buy order you want to return the frozen credits
            if (testTradesArray[iSaved][3].equals("1")){
                System.out.println("Cancel order and return "
                        + totalPrice + " credits to " + userOrg);
                //else if sell order, return the frozen assets
            } else if (testTradesArray[iSaved][3].equals("2")){
                System.out.println("Cancel order and return " + assetQty
                        + " " + assetName + " to " + userOrg);
            }
        }

        public void priceHistory(){
            try {
                new PriceHistoryGUI();
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            }
        }
    }

    public class PriceHistoryGUI extends JFrame {
        private final int noOfHistory = testPriceHistoryArray.length;
        private final Method graphMethod = PriceHistoryGUI.class.getMethod("graph");
        private final JButton graphButton = button("Graph", graphMethod, this, null,50,50);

        public PriceHistoryGUI() throws NoSuchMethodException {
            initUI();
        }

        private void initUI() {
            Container contentPane = this.getContentPane();
            contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
            contentPane.add(Box.createVerticalStrut(30));
            contentPane.add(makeInputPanel());
            contentPane.add(Box.createVerticalStrut(30));
            contentPane.add(makeButtonPanel());
            contentPane.add(Box.createVerticalStrut(30));
            setTitle("Price History - Trading Platform");
            setMinimumSize(new Dimension(400, 400));
            pack();
            setVisible(true);
        }

        private JScrollPane makeInputPanel(){
            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
            JScrollPane priceHistoryPanel = new JScrollPane(panel);
            priceHistoryPanel.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
            panel.add(Box.createVerticalStrut(15));
            for (int i = 0; i < noOfHistory; i++) {
                panel.add(Box.createHorizontalStrut(10));
                panel.add(new JLabel("Qty: "+ testPriceHistoryArray[i][0]
                        + "   $/per: " + testPriceHistoryArray[i][1]
                        + "   Transaction on: " + testPriceHistoryArray[i][2]));
                panel.add(Box.createVerticalStrut(30));
            }

            priceHistoryPanel.setMinimumSize(new Dimension(200,150));
            priceHistoryPanel.setPreferredSize(new Dimension(300,250));
            priceHistoryPanel.setMaximumSize(new Dimension(300,400));

            return priceHistoryPanel;
        }

        private JPanel makeButtonPanel(){
            JPanel buttonPanel = new JPanel();
            buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
            buttonPanel.add(Box.createHorizontalStrut(50));
            buttonPanel.add(graphButton);
            return buttonPanel;
        }

        public void graph(){
            System.out.println("Should open price history graph");
        }
        //opens from markerOrderViewGUI
        //shows previous completed orders of the same asset type
    }

}
