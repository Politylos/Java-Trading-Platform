import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;


public class Server_Connector {
    /*

     */
    private String IP;
    private int Port;
    private ServerSocket Connection;
    private ObjectOutputStream objstream;
    private Socket socket;
    private ObjectInputStream obj_in_stream;

    /**
     * creates Connector object
     * Connects to the main server via fetching IP and port from cnf file
     * @throws IOException ?
     */
    public Server_Connector() throws IOException {
        ConfigRead();
        //establish();
        //establish();

    }
    public Object fetch() throws IOException, ClassNotFoundException {
        InputStream inputstream = socket.getInputStream();
        obj_in_stream = new ObjectInputStream(inputstream);
        Object obj = obj_in_stream.readObject();
        inputstream.close();
        obj_in_stream.close();
        socket.close();
        return obj;

    }
    public void send(int command) throws IOException {
        send(command, new String[] {null});
    }
    public void send(int command, String[] args) throws IOException {
        System.out.println(command);
        objstream.writeObject(new pack(command,args));

    }
    public void close() throws IOException {
        objstream.close();
        obj_in_stream.close();
        socket.close();
    }
    public void establish() throws IOException {
            socket = new Socket(IP,Port);
            OutputStream outstream = socket.getOutputStream();
            objstream = new ObjectOutputStream(outstream);

    }
    public Socket getSocket(){
        return socket;
    }
    public ObjectInputStream get() throws IOException{
        InputStream inputstream = socket.getInputStream();
        obj_in_stream = new ObjectInputStream(inputstream);
        return obj_in_stream;
    }
    /**
     * This Function is used to update the IP adress and Port of the server from the config.con file
     * @throws FileNotFoundException ?
     */
    public void ConfigRead() throws FileNotFoundException {

        try {
            File ConfigFile = new File("config.cfg");
            Scanner ConfigRead = new Scanner(ConfigFile);
            while (ConfigRead.hasNextLine()){
                String line = ConfigRead.nextLine();
                /* remove ip to client only*/
                if(line.indexOf("IPAdress") != - 1) {
                    String[] separated = line.split("\"");
                    IP = separated[1];
                    System.out.println(IP);
                    ;
                }
                if(line.indexOf("Port") != - 1) {
                    String[] separated = line.split("\"");
                    Port = Integer.parseInt(separated[1]);
                    System.out.println(Port);
                }
            }
            ConfigRead.close();
        }catch(FileNotFoundException e){
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    /**
     * Creates a connection to the passed IP and Port
     * creating a severSocket connection
     * @param IP, String of ip to connect to
     * @param Port, String of port to connect to
     * @throws IOException ?
     */
    public void Connect(String IP, String Port) throws IOException{

    }

    /**
     * Closes down connection from server
     * @throws IOException ?
     */
    public void CloseConnection() throws IOException{

    }
}
