

public class Market_functions {
    private User user;

    /**
     * passes a new order request sending data to the server
     * @param assetid, int id of asset to buy
     * @param price, double buy price
     */
    public void PlaceOrder(int assetid, double price){

    }

    /**
     * passes a new sell request to the sever
     * @param assetid, int id of asset to list
     * @param price, double sell price
     */
    public void PlaceSell(int assetid, double price) {

    }
}
