import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.Serial;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.HashMap;

public class Market extends Parent_Market{
    @Serial
    private static final long serialVersionUID = -2856333223719086524L;
    User user;
    Server_Connector server;
    public Market() {
        super();
    }
    public Market(HashMap<Integer,Trade> t,HashMap<String,organisation> orgs, HashMap<String, Asset> assets ) throws SQLException, IOException, ClassNotFoundException, ParseException {
        this.trades = t;
        this.assets = assets;
        this.orgs = orgs;
    }
    public Market(User user) throws SQLException, IOException, ClassNotFoundException, ParseException {
        this.user = user;
    }
    public void fetchTrades(){

    }
    public void setUser(User u){
        this.user = u;
    }
    public HashMap<Integer,Trade> getTrades(){
        return trades;
    }

    public Trade getTrades(int id){
        return trades.get(id);
    }

    public Boolean PlaceSell(Asset asset, double price){
        throw new UnsupportedOperationException();
    }

    public Boolean PlaceBuy(Asset asset, double price){
        throw new UnsupportedOperationException();
    }

    public Boolean RemoveTrade(Trade trade){
        if (trade.getOrg() == user.getOrgID()) {
            //new pack(25, new String[] {String.valueOf(trade.getId()),trade.});
        }
        return false;
    }
    public Boolean Add_Trade(int org_id, int asset_id, double amount, double cost_per_asset, int type) throws IOException {
        if(org_id == user.getOrgID()) {
            String[] Information = {String.valueOf(asset_id), String.valueOf(amount), String.valueOf(cost_per_asset), String.valueOf(type)};
            new pack(25, Information);
            server.establish();
            server.send(25, Information);
            ObjectInputStream serial = server.get();
            try{
                System.out.println("Trade created");
                Trade trade = (Trade) serial.readObject();
                serial.close();
                return true;
            } catch (Exception e){
                System.out.println("Trade not created");
                serial.close();
                return false;
            }
        }
        return false;
    }

}
