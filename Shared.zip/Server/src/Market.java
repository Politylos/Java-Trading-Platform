//import org.graalvm.compiler.nodes.calc.UnpackEndianHalfNode;

import java.io.IOException;
import java.io.Serial;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Market extends Parent_Market{
    @Serial
    private static final long serialVersionUID = -2856333223719086524L;
    public Market() throws SQLException, IOException, ClassNotFoundException, ParseException {
        fetchTrades();
        fetchAssetes();
        fetchOrganisations();
        print();
    }
    public void print(){
        if(!assets.isEmpty()) {
            Iterator it = assets.entrySet().iterator();
            while(it.hasNext()) {
                Map.Entry obj = (Map.Entry)it.next();
                System.out.println(obj.toString());
            }
        }
    }
    public void fetchTrades() throws SQLException, IOException, ClassNotFoundException {
        DB dbconn = new DB();
        dbconn.query("SELECT * FROM trades, assets WHERE assets.Asset_id = trades.Asset_id");

        while (dbconn.next()){
            HashMap<String,String> row = dbconn.Pop();
            trades.put(Integer.parseInt(row.get("Trade_id")),new Trade(Integer.parseInt(row.get("Trade_id")),row.get("Name"), Integer.parseInt(row.get("Amount")), Double.parseDouble(row.get("Cost")), Integer.parseInt(row.get("Trade_type")), Integer.parseInt(row.get("Organisation_id")),row.get("Description") ));
        }
    }
    public void fetchAssetes() throws SQLException, IOException, ClassNotFoundException, ParseException {
        DB dbconn = new DB();
        dbconn.query("SELECT * FROM assets");
        while (dbconn.next()){
            HashMap<String,String> row = dbconn.Pop();
            assets.put(row.get("Name"), new Asset(Integer.parseInt(row.get("Asset_id")), row.get("Name"), row.get("Description")));
        }
    }
    public void fetchOrganisations() throws SQLException, IOException, ClassNotFoundException {
        DB dbconn = new DB();
        dbconn.query("SELECT * FROM organisations");
        while (dbconn.next()){
            HashMap<String,String> row = dbconn.Pop();
            orgs.put(row.get("Organisation_Name"),new organisation(Integer.parseInt(row.get("Organisation_id")),row.get("Organisation_Name"),Double.parseDouble(row.get("Credits"))));
        }
    }
    public HashMap<Integer, Trade> getTrades(){
        throw new UnsupportedOperationException();
    }

    public Trade getTrades(String name){
        throw new UnsupportedOperationException();
    }

    /*public void Add_Trade(int org_id, int asset_id, double amount, double cost_per_asset, int type) throws SQLException, IOException, ClassNotFoundException {
        DB dbconn = new DB();
        //read data from input stream
        //check to see if there are any
    }
    */
    private Boolean TradeMatch(){
        throw new UnsupportedOperationException();
    }

    public Boolean PlaceSell(Asset asset, double price){
        throw new UnsupportedOperationException();
    }

    public Boolean PlaceBuy(Asset asset, double price){
        throw new UnsupportedOperationException();
    }
    public Boolean RemoveTrade(Trade trade){
        throw new UnsupportedOperationException();
    }

    public void Add_Trade(int parseInt, String arg, String arg1, String arg2, String arg3, String arg4) {
    }
}
