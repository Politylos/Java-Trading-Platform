import com.sun.security.ntlm.Server;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.HashMap;


public class Run {
    public static void main(String[] args) throws IOException, SQLException, ClassNotFoundException, ParseException, NoSuchMethodException {
        DB DBconn = new DB();
        Server_Server server = new Server_Server();
        ServerGUI serverGUI = new ServerGUI(server);
        DBconn.query("SELECT * FROM assets");
        while (DBconn.next()) {
            HashMap<String,String> row = DBconn.Pop();
            //Asset asset_add = new Asset(Integer.parseInt(row.get("Asset_id")),row.get("Name"),row.get("Description"));
        }
    }
}

