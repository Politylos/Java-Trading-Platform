import java.io.*;
import java.net.*;
import java.io.File;  // Import the File class
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Scanner; // Import the Scanner class to read text files
import java.util.HashMap; // import the HashMap class
import java.util.Set;

public class Server_Server {
    private int Port;
    private String IP;
    private ServerSocket Ser_Sock;
    private HashMap<String,Socket> Connections;
    private boolean Open = true;
    private Market global_market;
    public boolean isRunning(){
        return Open;
    }
    public Server_Server() throws IOException, ClassNotFoundException, SQLException, ParseException {
        global_market = new Market();
        ConfigRead();
        Start();
        Connections = new HashMap<String, Socket>();
        run();
    }
    /**
     * main Function for server, used to allow the server to accept new connections and pass data back to the client
     * @throws IOException
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    public void closeSocket(Socket socket) throws IOException {
        Connections.remove(socket.toString());
        socket.close();
    }
    public void run() throws IOException, ClassNotFoundException, SQLException, ParseException {
        while (Open){
            Socket socket = Ser_Sock.accept();
            System.out.println(socket.toString());
            Connections.put(socket.toString(),socket);
            InputStream inputstream = socket.getInputStream();
            ObjectInputStream obj_stream = new ObjectInputStream(inputstream);
            pack command =  (pack) obj_stream.readObject();
            PassCommand(command.getType(),command.getArgs(),Connections.get(socket.toString()));
            System.out.println("New Pass through");
            /*System.out.println("type: "+command.getType()+"username: "+command.getArgs()[0]+" | password: "+command.getArgs()[1] );
            DbManager DBconn = new DbManager();
            DBconn.query("SELECT * FROM users");
            DBconn.FirstResult();
            System.out.println(DBconn.getColumn("password"));
            if (BCrypt.checkpw(command.getArgs()[1],DBconn.getColumn("password")))
                System.out.println("It matches");
            else
                System.out.println("It does not match");*/
        }
    }

    /**
     * This Function is used to update the IP adress and Port of the server from the config.con file
     * @throws FileNotFoundException ?
     */
    public void ConfigRead() throws FileNotFoundException {

        try {
            File ConfigFile = new File("config.cfg");
            Scanner ConfigRead = new Scanner(ConfigFile);
            while (ConfigRead.hasNextLine()){
                String line = ConfigRead.nextLine();
                /* remove ip to client only*/
                if(line.indexOf("IPAdress") != - 1) {
                    String[] separated = line.split("\"");
                    IP = separated[1];
                    System.out.println(IP);
                    ;
                }
                if(line.indexOf("Port") != - 1) {
                    String[] separated = line.split("\"");
                    Port = Integer.parseInt(separated[1]);
                    System.out.println(Port);
                }
            }
            ConfigRead.close();
        }catch(FileNotFoundException e){
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    /**
     * The Start Function is used to open the server to a socket that is specifed by the Port variable
     * @throws IOException ?
     */
    public void Start() throws IOException {
        Ser_Sock = new ServerSocket(Port);
    }

    /**
     * this method add a new user client connection to the server, allowing for communication bettween the two
     * @throws IOException ?
     */
    public void NewConnection() throws IOException{
        Socket newCon = Ser_Sock.accept();
        InputStream istream = newCon.getInputStream();
        BufferedReader receiveRead = new BufferedReader(new InputStreamReader(istream));
        Connections.put(receiveRead.readLine(),newCon);

    }

    /**
     * This method shuts the server down safely
     * @throws IOException ?
     */
    public void Shutdown() throws IOException {
        Open = false;
        Ser_Sock.close();
        System.out.println("Shutting down Server");
    }

    /**
     * The send function enables the server to pass a serializable object to the cleint, through specifing the object to send and the
     * socket to send to
     * @param toPass an object that is serializable to send to the specified client socket
     * @param socket a Socket object that specifies the client to send the information to
     * @throws IOException
     */
    public void send(Object toPass, Socket socket) throws IOException {
        OutputStream outstream = socket.getOutputStream();
        ObjectOutputStream objstream = new ObjectOutputStream(outstream);
        objstream.writeObject(toPass);
        outstream.close();
        objstream.close();
    }

    /**
     * this function is used bhy the server when a packet object is received. This function
     * takes the packs command and argument, which this function is than able to interrupt
     * into constructing the correct object or passing the args to the relevant function
     * @param command an int variable that specifies the function to preform
     * @param args a list of Strings that are to be passed to the relevant command
     * @param socket A socket object that specifies the client that requested the following command
     * @throws SQLException
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public void PassCommand(int command, String[] args,Socket socket) throws SQLException, IOException, ClassNotFoundException, ParseException {
        //login
        if (command == 10){
            User user = new User();
            user.Login(args[0],args[1]);
            if (user.getId() > 0) {
                send(user, socket);
            } else{
                send(null, socket);
            }
        }
        //set new password
        else if (command == 11){}
        //view assets
        else if (command == 12){}
        // view market place
        else if (command == 20){}
        //sell request
        else if (command == 21){}
        //buy request
        else if (command == 22){}
        //view asset
        else if (command == 23){}
        //view trade listing
        else if (command == 24){}
        //add trade
        else if (command == 25){
            Market market = new Market();
            market.Add_Trade(Integer.parseInt(args[0]),args[1],args[2],args[3],args[4],args[5]);
        }
        //add user
        else if (command == 30){}
        //Add org
        else if (command == 31){}
        //add asset
        else if (command == 32){}
        //add asset to org
        else if (command == 33){}
        //add credit to org
        else if (command == 34){}
        //remove user
        else if (command == 35){}
        //remove org
        else if (command == 36){}
        //remove asset
        else if (command == 37){}
        //get credits
        else if (command == 40){}
        //get assets
        else if (command == 41){}
        //get org assets
        else if (command == 42){}
        //get org names
        else if (command == 43){
            organisation Org = new organisation();
            Set<String> orgNames = Org.getOrgNameList();
            send(orgNames,socket);
        }
        //close connection
        else if (command == 44){}
        //get market place
        else if (command == 45){
            System.out.println("sending market");
            send(global_market, socket);
        }
        closeSocket(socket);
    }

}
