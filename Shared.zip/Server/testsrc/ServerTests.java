import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;

public class ServerTests {


    /* Test pre conditions

     */
    @BeforeEach @Test
    public void testPreConditions() {
        //
    }

    @Test
    public void testOne(){
        //
    }
}
